/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Operadores
        
        //Operadores aritm�ticos
        /*
        + suma
        - resta
        * multiplicaci�n
        / divisi�n
        % m�dulo o resto de la divisi�n
        Son operadores binarios porque necesitan 2 operandos
        Los operandos son num�ricos y el resultado es num�rico
        */
        
        int nro1 = 10;
        int nro2 = 2;
        
        System.out.print("Suma: ");
        System.out.println(nro1 + nro2);
        
        System.out.print("Resta: ");
        System.out.println(nro1 - nro2);
        
        System.out.print("Multiplicaci�n: ");
        System.out.println(nro1 * nro2);
        
        System.out.print("Divisi�n: ");
        System.out.println(nro1 / nro2);
        
        System.out.print("M�dulo o resto de la divisi�n: ");
        System.out.println(nro1 % nro2);
        
        
        /*
        Operadores de asignaci�n
        = igual (asignaci�n)
        += suma y asignaci�n
        -= resta y asignaci�n
        *= multiplicaci�n y asignaci�n
        /= divisi�n y asignaci�n
        %= m�dulo y asignaci�n
        Son operadores binarios.
        Asignan el valor a una variable y se la modifican utilizando una expresi�n
        */
        
        System.out.println(nro1); //nro1 vale 10
        nro1 = 12; //con el = se le asigna el valor que est� a la derecha (literal)
        System.out.println(nro1); //nro1 ahora vale 12
        
        nro1 += 2; //con el += se le suma y asigna 2 al valor de la variable
        //es lo mismo que hacer: nro1 = nro1 + 2
        System.out.println(nro1); //nro1 ahora vale 14
        
        nro1 -= 2; //con el -= se le resta y asigna 2 al valor de la variable
        System.out.println(nro1); //nro1 ahora vale 12
        
        nro1 *= 2; //con el *= se multiplica y asigna por 2 al valor de la variable
        System.out.println(nro1); //nro1 ahora vale 24
        
        nro1 /= 2; //con el /= se divide y asigna por 2 al valor de la variable
        System.out.println(nro1); //nro1 ahora vale 12
        
        nro1 %= 2; //con el %= se le asigna el valor del resto de la divisi�n
                //entre el valor de la variable y 2
        System.out.println(nro1); //nro1 ahora vale 0
        
        
        //Operadores incrementales y decrementales
        /*
        ++ incrementa en 1
        -- decrementa en 1
        Son operadores unarios, trabajan con un solo operando.
        */
        nro1++; //incrementa en 1 el valor de la variable
        //es lo mismo que: nro1 = nro1 + 1
        //es lo mismo que: nro1 += 1
        System.out.println(nro1); //nro1 ahora vale 1
        
        nro1--; //decrementa en 1 el valor de la variable
        System.out.println(nro1); //nro1 ahora vale 0
        
        
        //Operadores relacionales
        /*
        > mayor
        < menor
        >= mayor o igual
        <= menor o igual
        == igual
        != distinto
        Son operadores binarios.
        Los operandos son num�ricos y el resultado es booleano.
        */
        
        nro1 = 15;
        nro2 = 20;
        
        System.out.println(nro1 > nro2); //false
        System.out.println(nro1 < nro2); //true
        System.out.println(nro1 >= nro2); //false
        System.out.println(nro1 <= nro2); //true
        System.out.println(nro1 == nro2); //false
        System.out.println(nro1 != nro2); //true
        
        
        //Tabla de verdad
        //Es una representaci�n l�gica de resultados
        /*
        A   B   AND OR
        V   V   V   V
        V   F   F   V
        F   V   F   V
        F   F   F   F
        
        Negaci�n (NOT)
        A   NOT
        V   F
        F   V
        */
        
        
        //Operadores l�gicos
        /*
        & AND
        | OR
        ! NOT
        Los operandos son booleanos.
        El resultado es booleano.
        */
        
        boolean log1 = true;
        boolean log2 = false;
        
        /*
        Un solo operador l�gico & � | eval�a ambas condiciones.
        Al utilizar dos && � || si con una condici�n determina el valor de verdad,
        no eval�a la condici�n que sigue
        */
        
        System.out.print("AND && ");
        System.out.println(log1 && log2);
        
        System.out.print("OR || ");
        System.out.println(log1 || log2);
        
        System.out.println("NOT ! ");
        System.out.println(!log1);
        System.out.println(!log2);
        
        
        
        
    }
    
}
