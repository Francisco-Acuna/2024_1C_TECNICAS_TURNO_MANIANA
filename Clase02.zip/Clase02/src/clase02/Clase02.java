/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase02;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        System.out.println("Hola Mundo!!");
        
        // Comentarios
        
        // comentario en l�nea
        
        /*
        Esto es un bloque de comentarios.
        Podemos escribir en varias l�neas.
        */
        
        /**
         * Esto es un comentario de JavaDox
         * Podemos escribir en varias l�neas.
         * Se utiliza para documentar
         * m�todos, clases, interfaces.
         */
        
        System.out.println("Hello World!"); //esto es una sentencia
        //una sentencia es una orden que se le da al programa
        //para realizar una tarea espec�fica.
        //las sentencias finalizan con el ;
        //el ; separa una sentencia de otra.
        
        //impresi�n con salto de l�nea
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");
        
        //impresi�n sin salto de l�nea
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.print("5");
        
        System.out.println("");
        
        //Variables
        /*
        Una variable es un nombre que se asocia con una porci�n de la memoria
        del ordenador, en donde se guarda el valor asignado a esa variable.
        Las variables deben declararse antes de usarlas.
        La declaraci�n es una sentencia en la que figura el tipo de dato
        y el nombre que le asignamos a la variable.
        */
        
        

//declaraci�n de variable con nombre y tipo de dato
        int a = 2; //asignaci�n de valor a la variable con el operador =
        int b = 3; //declaraci�n y asignaci�n de valor en una misma l�nea
        
        a=4; //cambiamos el valor de la variable a
//        a="Hola"; ERROR, no se puede asignar otro tipo de dato como valor de
//la variable.
//        char a; ERROR, la variable a ya est� declarada, no se puede volver a declarar

        //Una variable puede tener una �nica declaraci�n e innumerables valores
        //los valores deben ser siempre del mismo tipo de dato.
        
        int c=12, d=32, e=41; //declaraci�n y asignaci�n m�ltiple en l�nea.
        
        //Tipos de datos primitivos
        
        //byte - ocupa 1 byte y representa un n�mero entero entre -128 y 127
        byte f = 100;
        System.out.println(f); //imprime el valor de la variable
        
        //short - ocupa 2 bytes y representa un n�mero entero entre -32.768
        //y 32.767
        short g = 31500;
        System.out.println(g);
        
        //int - ocupa 4 bytes y representa un n�mero entero entre 
        //-2.147.483.648 y 2.147.483.647
        int h = -53648325;
        System.out.println(h);
        
        //long - ocupa 8 bytes y representa un valor muy grande
        long i = 2365489765423L; //debemos colocar una L al final
        //por convenci�n utilizamos la L may�scula
        System.out.println(i);
        
        //float - ocupa 4 bytes y tiene una precisi�n de 32 bits
        float j = 14.25f; //debemos colocarle una f al final del valor asignado
        //el . separa los decimales, no se utiliza la coma.
        System.out.println(j);
        
        //double - ocupa 8 bytes y tiene una precisi�n de 64 bits
        double k = 23.45; //no hace falta agregarle una letra al final del valor
        System.out.println(k);
        
        //diferencia entre float y double
        float fl = 10f;
        double dl = 10;
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        //boolean - ocupa 1 byte y almacena solo 2 valores (0 y 1)
        //que son representados por true y false
        boolean l = true; //asigna el valor true que representa "verdad"
        boolean m = false; //asigna el valor false que representa "falso"
//        boolean n = 1; ERROR no lee el n�mero entero S�lo admite las
        //palabras reservadas "true" y "false".
        System.out.println(l);
        System.out.println(m);
        
        //char - ocupa 2 bytes, almacena un entero que representa un caracter
        //de la tabla unicode
        //unicode es un est�ndar de codificaci�n mundial de caracteres
        char n = 65; //se almacena como un n�mero entero, pero representa 
        //el caracter A
        System.out.println(n);
        //si a una letra may�scula le sumo 32, la paso a min�scula
        n += 32; //ahora la variable vale 97
        System.out.println(n);
        //tambi�n podemos almacenar la variable con el caracter directamente
        n = 'f'; //el caracter asignado se debe encerrar entre comillas simples
        System.out.println(n);
        
        //String - NO ES UN TIPO DE DATO PRIMITIVO, representa una cadena de caracteres
        String o = "Hola"; //al ser una clase y no un tipo de dato primitivo, 
        //se debe escribir con may�scula
        //el valor asignado a un tipo de dato String, debe ir encerrado entre ""
        String p = "Hola, soy una cadena de caracteres!";
        System.out.println(o);
        System.out.println(p);
        
        //CONSTANTES
        //son similares a las variables, pero la diferencia es que su valor
        //no puede cambiar.
        final double PI = 3.14; //para declarar constantes, debemos utilizar la 
        //palabrar reservada "final"
        //por convenci�n, el nombre de las constantes va todo en may�scula
        System.out.println(PI);
        
        
        
        
    }

}
