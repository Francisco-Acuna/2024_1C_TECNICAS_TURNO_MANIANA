/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase03;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Operador de concatenaci�n
        //el + se utiliza para concatenar
        
        String nombre = "Marcela89";
        String apellido = "L�pez";
        
        System.out.println(nombre); //sin comillas imprimo el valor de la variable
        System.out.println("El nombre de la persona es: " + nombre);
        System.out.println("Su nombre es: " + nombre + " y su apellido es: " + apellido);
        
        String palabra1 = "uesta";
        String palabra2 = "subir";
        String palabra3 = "la";
        String palabra4 = "a";
        String palabra5 = "e";
        String palabra6 = "l";
        String palabra7 = "v";
        String palabra8 = "s";
        String palabra9 = "n";
        String palabra10 = "d";
        String palabra11 = "y";
        String palabra12 = "medio";
        String palabra13 = "C";
        
        //A Cuesta le cuesta subir la cuesta. Y en medio de la cuesta, va y
//se acuesta

        System.out.println(palabra4.toUpperCase() + " " + palabra13 + palabra1 + " " + palabra6 
                + palabra5 + " " + palabra13.toLowerCase() + palabra1 + " " + palabra2 + " " 
                + palabra3 + " " + palabra13.toLowerCase() + palabra1 + ". " 
                + palabra11.toUpperCase() + " "  + palabra5 + palabra9 + " " + palabra12 
                + " " + palabra10 + palabra5 + " "  + palabra6 + palabra4 + " " 
                + palabra13.toLowerCase() + palabra1 + ", " + palabra7 + palabra4 + " " 
                + palabra11 + " " + palabra8 + palabra5 + " " + palabra4 + palabra13.toLowerCase()
                + palabra1 + ".");
        
    }
    
}
