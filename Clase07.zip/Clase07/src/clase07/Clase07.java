

package clase07;


public class Clase07 {
    public static void main(String[] args) {
        /*
        Convenciones de escritura:
        
        - camelCase -> estaEsUnaFraseEnCamelCase (tambi�n se la conoce
        como lower camel case)
        - PascalCase -> EstaEsUnaFraseEnPascalCase (tambi�n se la conoce
        como upper camel case)
        - snake_case -> esta_es_una_frase_en_snake_case
        */
        
        //Clase String
        //la clase String contiene un vector de caracteres
        System.out.println("** Clase String **");
        
        //podemos crear un objeto de la clase String de varias maneras:
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //m�todos para comparar
        //al comparar con el operador == va a comparar que sean el mismo
        //objeto en memoria
        System.out.println(texto2 == "hola"); //false
        
        //hay una oportunidad en la que la comparaci�n podr�a darnos 'true'
        System.out.println(texto3 == "hola"); //true
        /*
        Esto pasa porque se da un comportamiento particular denominado
        "intering". Lo que sucede es que las cadenas creadas con comillas
        dobles se almacenan en un pool de cadenas internas para ahorrar
        memoria. Es decir, que de manera interna, ocupar�an el mismo
        espacio en memoria, por eso las considera iguales.
        Comparar contenidos de cadenas con el == no brinda un comportamiento
        garantizado.
        */
        
        //para comparar cadenas de caracteres teniendo en cuenta su contenido,
        //se utilizan .equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        //.equals() compara literalmente las cadenas
        System.out.println(texto2.equals("HOLA")); //false
        //.equalsIgnoreCase() ignora las min�sculas y may�sculas
        System.out.println(texto2.equalsIgnoreCase("HOLA")); //true
        //estos m�todos retornan un valor booleano
        
        //.contains()
        //devuelve un booleano si contiene la subcadena que pasamos
        //como par�metro
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("hola")); //true
        
        //.length()
        //devuelve la longitud del vector
        //es decir, cu�ntos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //indica si la cadena est� vac�a
        //es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false
        
        //.isBlank() aparece a partir del JDK 11
        //indica si una cadena est� en blanco o si consiste 
        //�nicamente en espacios en blanco, como por ejemplo
        //si solo contiene espacios, tabulaciones y/o saltos de l�nea
        String texto4 = "    ";
        System.out.println(texto4.isEmpty()); //false
        //no toma a la cadena como vac�a porque tiene en cuenta los espacios
        System.out.println(texto4.isBlank()); //true
        //entiende que los espacios en blanco no significan contenido
        
        //.charAt()
        //devuelve el caracter del �ndice pasado como par�metro
        System.out.println(texto1.charAt(3));
        System.out.println(texto2.charAt(3));
        
        //.indexOf()
        //devuelve el �ndice de la primera ocurrencia de la subcadena
        //si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto"));
        //devuelve -1 porque la T es may�scula
        System.out.println(texto1.indexOf("Texto")); //10
        
        //.trim()
        //quita los espacios de adelante y atr�s
        System.out.println("    buenas noches   ");
        System.out.println("    buenas noches   ".trim());
        
        //.startsWith() .endsWith()
        //devuelve un booleano indicando si la cadena comienza o
        //termina con un texto determinado
        System.out.println(texto1.startsWith("hola")); //false
        System.out.println(texto2.startsWith("hola")); //true
        System.out.println(texto1.endsWith("exto")); //false
        System.out.println(texto1.endsWith("exto!")); //true
        
        //m�todos replace
        //reemplazan un caracter por otro
        System.out.println(texto1.replace('e', 'i'));
        //reemplazar una cadena de caracteres por otra
        System.out.println(texto1.replace("Texto", "caracteres"));
        //reemplazar s�lo la primera vez que aparezca la cadena
        texto3 = "manzana, manzana, naranja";
        System.out.println(texto3.replaceFirst("manzana", "banana"));
        //reemplazar todas las veces que aparezca la cadena
        System.out.println(texto3.replaceAll("manzana", "banana"));
        
        /*
        Si bien el replace() tambi�n reemplaza todas las veces que
        aparezca la subcadena, el replaceAll() es m�s potente. Nos
        permite buscar y reemplzar patrones de expresiones regulares.
        Una expresi�n regular es una secuencia de caracteres que 
        definen un patr�n de b�squeda.
        */
        
        String texto5 = "Mi n�mero de tel�fono es 011-8888-9999 y mi"
                + " otro n�mero es 365-1010-2727";
        
        System.out.println(texto5.replaceAll("\\d{3}-\\d{4}-\\d{4}",
                "TEL�FONO"));
        //en este ejemplo utilizamos un patr�n de expresi�n regular
        //que busca todas las ocurrencias de una cadena de caracteres
        //que coincida con el formato de ###-####-####
        
    }
}
