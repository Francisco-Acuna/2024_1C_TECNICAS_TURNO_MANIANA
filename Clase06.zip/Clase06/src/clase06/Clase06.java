

package clase06;


public class Clase06 {
    public static void main(String[] args) {
        /*
        Convenciones de escritura:
        
        - camelCase -> estaEsUnaFraseEnCamelCase (tambi�n se la conoce
        como lower camel case)
        - pascalCase -> EstaEsUnaFraseEnPascalCase (tambi�n se la conoce
        como upper camel case)
        - snake_case -> esta_es_una_frase_en_snake_case
        */
        
        //Clase String
        //la clase String contiene un vector de caracteres
        System.out.println("** Clase String **");
        
        //podemos crear un objeto de la clase String de varias maneras:
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //m�todos para comparar
        //al comparar con el operador == va a comparar que sean el mismo
        //objeto en memoria
        System.out.println(texto2 == "hola"); //false
        
        //hay una oportunidad en la que la comparaci�n podr�a darnos 'true'
        System.out.println(texto3 == "hola"); //true
        /*
        Esto pasa porque se da un comportamiento particular denominado
        "intering". Lo que sucede es que las cadenas creadas con comillas
        dobles se almacenan en un pool de cadenas internas para ahorrar
        memoria. Es decir, que de manera interna, ocupar�an el mismo
        espacio en memoria, por eso las considera iguales.
        Comparar contenidos de cadenas con el == no brinda un comportamiento
        garantizado.
        */
        
        //para comparar cadenas de caracteres teniendo en cuenta su contenido,
        //se utilizan .equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        //.equals() compara literalmente las cadenas
        System.out.println(texto2.equals("HOLA")); //false
        //.equalsIgnoreCase() ignora las min�sculas y may�sculas
        System.out.println(texto2.equalsIgnoreCase("HOLA")); //true
        
        
    }
}
