/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase05;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*
        Dados n1=5, n2=10 y n3=20. Informar:
        a) n1+n2
        b) n3-n1
        c) n1*n3
        d) n3/n2
        */
        
        //Ejercicio 1
        System.out.println("Ejercicio 1:");
        int n1=5, n2=10, n3=20;
        
        System.out.println("EL resultado de n1+n2 es: " + (n1+n2));
        System.out.println("El resultado de n3-n1 es: " + (n3-n1));
        System.out.println("El resultado de n1*n3 es: " + (n1*n3));
        System.out.println("El resultado de n3/n2 es: " + (n3/n2));
        
        
        /*
        Dados n1=10, n2=20 y n3=30. Informar :
        a) El total de la suma de todas las variables
        b) El promedio
        c) El resto entre n2 y n1
        */
        System.out.println("***************************");
        System.out.println("Ejercicio 2");
        n1=10;
        n2=20;
        n3=30;
        
        int sumaTotal = n1+n2+n3;
        int promedio = sumaTotal / 3;
        int resto = n2 % n1;
        
        System.out.println("El total de la suma de todas las variables es: " + sumaTotal);
        System.out.println("El promedio es: " + promedio);
        System.out.println("El resto entre n2 y n1 es: " + resto);
        
        
        
    }
    
}
